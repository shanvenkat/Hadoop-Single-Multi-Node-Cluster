'use strict';

angular.module('efileConfig', [])
  .constant('configuration', {
    allowedFileTypes: 'image/jpeg,application/pdf'
  });