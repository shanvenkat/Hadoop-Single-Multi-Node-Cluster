define([
    'jquery',
    'backbone'
], function($, Backbone) {

   var LookupModel = Backbone.Model.Extend({

   });   

   return LookupModel;  
});